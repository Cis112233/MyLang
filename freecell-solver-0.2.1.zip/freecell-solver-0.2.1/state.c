

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "config.h"
#include "state.h"
#include "card.h"

#ifdef FAST_STATES

card_t empty_card = {0,0};

int card_compare(const void * card1, const void * card2)
{
    const card_t * c1 = (const card_t *)card1;
    const card_t * c2 = (const card_t *)card2;

    if (c1->card_num > c2->card_num)
    {
        return 1;
    }
    else if (c1->card_num < c2->card_num)
    {
        return -1;
    }
    else
    {
        if (c1->deck > c2->deck)
        {
            return 1;
        }
        else if (c1->deck < c2->deck)
        {
            return -1;
        }
        else
        {
            return 0;
        }            
    }
}

int stack_compare(const void * s1, const void * s2)
{
    card_t card1 = ((const fc_stack_t *)s1)->cards[0];
    card_t card2 = ((const fc_stack_t *)s2)->cards[0]; 

    return card_compare(&card1, &card2);
}

void canonize_state(state_t * state)
{
    qsort(state->stacks, 8, sizeof(fc_stack_t), stack_compare);

    qsort(state->freecells, 4, sizeof(card_t), card_compare);
}

void state_init(state_t * state)
{
    memset((void*)state, 0, sizeof(state_t));
}

int state_compare(const void * s1, const void * s2)
{
    return memcmp(s1,s2,sizeof(state_t));
}

void f(char*s,char*toString)
{
    char c,i=0,j=0;
    int num=0;
    while(c=*(s++))
        { 
            
            toString[num]=c; 
          //  putchar(c);
            if(c==' ')++i;
            if((j<4&&i==7)||(j>=4&&i==6))
                {
                    i=0;
                    ++j;
                    toString[num]='\n';
                   // putchar('\n');
                    
                } 
                num++;
        }
}

state_t initial_user_state_to_c(char * string)
{
    char * sting;
    sting = malloc(200);
    state_t ret;
    int s,c;
    char * str;
    str = string;
    card_t card;
    state_init(&ret);
    f(str,sting);
    str = sting;
    for(s=0;s<8;s++)
    {
        /* Move to the next stack */
        if (s!=0)
        {
            while((*str) != '\n')
            {
                str++;
            }
            str++;
        }

        
        for(c=0;;c++)
        {
            /* Move to the next card */
            if (c!=0)
            {
                while(((*str) != ' ') && ((*str) != '\n'))
                {
                    str++;
                }
                if (*str == '\n')
                {
                    break;
                }
                str++;              
            }

            card = card_user2perl(str);
            push_card_into_stack(ret, s, card);
        }        
    }

    return ret;
}

char * state_as_string(state_t * state)
{
    char * string;
    char freecells[4][4], decks[4][4], stack_card[4];
    int a, card_num_is_null;
    int max_num_cards, s, card_num;

    string = (char*)malloc(1024);
    for(a=0;a<4;a++)
    {
        p2u_card_number(state->decks[a], decks[a], &card_num_is_null);
        if (decks[a][0] == ' ')
            decks[a][0] = '0';
    }

    sprintf(string, "%3s %3s %3s %3s        H-%1s S-%1s D-%1s C-%1s\n",
            card_perl2user(state->freecells[0], freecells[0]),
            card_perl2user(state->freecells[1], freecells[1]),
            card_perl2user(state->freecells[2], freecells[2]),
            card_perl2user(state->freecells[3], freecells[3]),
            decks[0],
            decks[1], 
            decks[2],
            decks[3]);

    sprintf(string+strlen(string), "--- --- --- ---\n");
    sprintf(string+strlen(string), "\n --  --  --  --  --  --  --  --\n");

    max_num_cards = 0;
    for(s=0;s<8;s++)
    {
        if (stack_len(*state, s) > max_num_cards)
        {
            max_num_cards = stack_len(*state, s);
        }
    }

    for(card_num=0;card_num<max_num_cards;card_num++)
    {
        for(s = 0; s<8; s++)
        {
            if (card_num > stack_len(*state, s))
            {
                strcat(string, "    ");
            }
            else
            {
                sprintf(string+strlen(string), "%3s ", card_perl2user(state->stacks[s].cards[card_num], stack_card));

            }
        }
        strcat(string, "\n");
    }
    return string;
}
        

#elif defined(COMPACT_STATES)

#endif
