/*
 * state.h - header file for state functions and macros for Freecell Solver
 *
 * Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000
 *
 * This file is in the public domain (it's uncopyrighted).
 */
#include "config.h"

#ifndef __STATE_H
#define __STATE_H

#ifdef _cplusplus
extern "C" {
#endif

#ifdef FAST_STATES

struct struct_card_t
{
    short card_num;
    short deck;
};

typedef struct struct_card_t card_t;

extern card_t empty_card;

struct struct_stack_t
{
    int num_cards;
    card_t cards[19];
};

typedef struct struct_stack_t fc_stack_t;

struct struct_state_t
{
    fc_stack_t stacks[8];
    card_t freecells[4];
    int decks[4];
};

typedef struct struct_state_t state_t;

#define stack_len(state, s) \
    ( (state).stacks[(s)].num_cards )    

#define stack_card_num(state, s, c) \
    ( (state).stacks[(s)].cards[(c)].card_num )

#define stack_card_deck(state, s, c) \
    ( (state).stacks[(s)].cards[(c)].deck )

#define stack_card(state, s, c) \
    ( (state).stacks[(s)].cards[(c)] )

#define card_card_num(card) \
    ( (card).card_num )

#define card_deck(card) \
    ( (card).deck )

#define freecell_card(state, f) \
    ( (state).freecells[(f)] )
    
#define freecell_card_num(state, f) \
    ( (state).freecells[(f)].card_num )
    
#define freecell_card_deck(state, f) \
    ( (state).freecells[(f)].deck )

#define deck_value(state, d) \
    ( (state).decks[(d)] )

#define increment_deck(state, d) \
    ( (state).decks[(d)]++ )
    
#define pop_stack_card(state, s, into) \
    into = (state).stacks[(s)].cards[(state).stacks[(s)].num_cards-1]; \
    (state).stacks[(s)].cards[(state).stacks[(s)].num_cards-1] = empty_card; \
    (state).stacks[(s)].num_cards--;
    
#define push_stack_card_into_stack(state, ds, ss, sc) \
    (state).stacks[(ds)].cards[(state).stacks[(ds)].num_cards] = (state).stacks[(ss)].cards[(sc)]; \
    (state).stacks[(ds)].num_cards++;
    
#define push_card_into_stack(state, ds, from) \
    (state).stacks[(ds)].cards[(state).stacks[(ds)].num_cards] = (from); \
    (state).stacks[(ds)].num_cards++;

#define duplicate_state(dest, src) \
    (dest) = (src);

#define put_card_in_freecell(state, f, card) \
    (state).freecells[(f)] = card;

#define empty_freecell(state, f) \
    (state).freecells[(f)] = empty_card;
    
#elif defined(COMPACT_STATES)

#endif

extern void canonize_state(state_t * state);
extern int state_compare(const void * s1, const void * s2);
extern void state_init(state_t * state);
extern state_t initial_user_state_to_c(char * string);
extern char * state_as_string(state_t * state);

#ifdef _cplusplus
}
#endif

#endif /* __STATE_H */
