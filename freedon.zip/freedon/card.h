


#ifndef __CARD_H
#define __CARD_H

#ifdef _cplusplus
extern "C" {
#endif

#ifndef __STATE_H
#include "state.h"
#endif

extern card_t card_user2perl(char * str);
extern char * card_perl2user(card_t card, char * str);
extern char * p2u_card_number(short num, char * str, int * card_num_is_null);

#ifdef _cplusplus
}
#endif

#endif /* __CARD_H */
