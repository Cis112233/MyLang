#include <stdio.h>
#include <stdlib.h>
#include <search.h>
#include <string.h>
#include "config.h"
#include "state.h"
#include "card.h"
#ifdef DEBUG
#include <signal.h>
#endif
int calc_max_sequence_move(  int fc_num,    int fs_num     ){    if (fs_num == 0)    {  return fc_num+1;    }    else if (fs_num == 1)    {  return 2*(fc_num+1);    }    else if (fs_num == 2)    {  if (num_prev_states - unsorted_prev_states_start_at >
= PREV_STATES_SORT_MARGIN){    qsort(prev_states, num_prev_states, sizeof(state_t), state_compare);    unsorted_prev_states_start_at = num_prev_states;}  }     if (check)  {ret = solve_for_state(new_state, depth+1);if (!ret){    solution_states[depth] = state_as_string(&state);    return 0;}  }    }}  }    }    return 1;}
#ifdef DEBUG
int command_num = 0;void select_signal_handler(int signal_num){    command_num = (command_num+1)%3;}void command_signal_handler(int signal_num){    if (command_num == 0)    {  fprintf(stderr, "The number of iterations is %i\n", num_times);    }    else if (command_num == 1)    {  debug_iter_output = ! debug_iter_output;    }    else if (command_num == 2)    {  debug_iter_state_output = ! debug_iter_state_output;    }    command_num = 0;}
#endif
char * help_string = "fc-solve [options] board_file\n""\n""If board_file is - or unspecified reads standard input\n""\n""Availalble Options:\n""-h   --help     - display this help screen\n""-i   --iter-output    - display the iteration number and depth in every state that is checked\n""( applicable only for fc-solve-debug )\n""-s   --state-output   - also output the state in every state that is checked\n""( applicable only for fc-solve-debug )\n""\n""Signals: (applicable only for fc-solve-debug)\n""SIGUSR1 - Prints the number of states that were checked so far to stderr.\n""SIGUSR2 SIGUSR1 - Turns iteration output on/off.\n""SIGUSR2 SIGUSR2 SIGUSR1 - Turns iteration's state output on/off.\n""\n";int main(int argc, char * argv[]){    char user_state[1024];    FILE * file;    state_t state;    int a;    int ret;    int arg;    for(arg=1;arg<argc;arg++)    {  if ((!strcmp(argv[arg], "-h")) || (!strcmp(argv[arg], "--help")))  {printf("%s", help_string);return 0;  }  else if ((!strcmp(argv[arg], "-i")) || (!strcmp(argv[arg], "--iter-output")))  {debug_iter_output = 1;  }  else if ((!strcmp(argv[arg], "-s")) || (!strcmp(argv[arg], "--state-output")))  {debug_iter_state_output = 1;  }  else  {break;  }      }        if ((arg == argc) || (!strcmp(argv[arg], "-")))    {  file = stdin;    }    else    {  file = fopen(argv[arg], "r");    }    fread(user_state, sizeof(user_state[0]), sizeof(user_state)/sizeof(user_state[0]), file);    fclose(file);         state = initial_user_state_to_c(user_state);    canonize_state(&state);    max_num_prev_states = PREV_STATES_GROW_BY;    prev_states = (state_t *)malloc(max_num_prev_states*sizeof(state_t));    prev_states[0] = state;    num_prev_states = 1;
#ifdef DEBUG
    signal(SIGUSR1, command_signal_handler);    signal(SIGUSR2, select_signal_handler);
#endif
        ret = solve_for_state(state, 0);    if (!ret)    {  int a;  printf("-=-=-=-=-=-=-=-=-=-=-=-\n\n");  for(a=0;a<num_solution_states;a++)  {printf("%s\n\n====================\n\n", solution_states[a]);free((void*)solution_states[a]);  }  free((void*)solution_states);    printf("This game is solveable.\n");    }    else    {  free(prev_states);  printf ("I couldn't solve this game.\n");    }    printf ("Total number of states checked is %i.\n", num_times);    return 0;}