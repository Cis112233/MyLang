
#include <stdio.h>
#include <stdlib.h>
#include <search.h>
#include <string.h>

#include "config.h"
#include "state.h"
#include "card.h"
#ifdef DEBUG
#include <signal.h>
#endif

int calc_max_sequence_move(
        int fc_num,  
        int fs_num   
        )
{
    if (fs_num == 0)
    {
        return fc_num+1;
    }
    else if (fs_num == 1)
    {
        return 2*(fc_num+1);
    }
    else if (fs_num == 2)
    {
        return (3*(fc_num+1) + 1);
    }
    else if (fs_num == 3)
    {
        return (4*(fc_num+1)+3);
    }
    else if (fs_num == 4)
    {
        return (5*(fc_num+1)+5);
    }
    else if (fs_num >= 5)
    {
        return 13;
    }    
}

#define min(a,b) (((a)<(b))?(a):(b))

#define PREV_STATES_GROW_BY 128
#define PREV_STATES_SORT_MARGIN 16
state_t * prev_states;
int num_prev_states = 0;
int max_num_prev_states = 0;
int unsorted_prev_states_start_at = 0;

int num_times = 0;

int debug_iter_output = 0;
int debug_iter_state_output = 0;

char * * solution_states;
int num_solution_states;

int solve_for_state(state_t state, int depth)
{
    int stack, cards_num;
    card_t card;
    state_t new_state;
    int ret;
    int fc, dest_stack, dest_cards_num; 
    card_t dest_card, temp_card;
    int a,b;
    int check;
    size_t temp_size_t;

#ifdef DEBUG
    int iter_num = num_times;
#endif
    num_times++;


#ifdef DEBUG
    if (debug_iter_output)
    {
        fprintf(stdout, "Iteration: %i\n", iter_num);
        fprintf(stdout, "Depth: %i\n\n", depth);
    
    
        if (debug_iter_state_output)
        {
            char * state_string = state_as_string(&state);
            printf("%s\n---------------\n\n\n", state_string);
            free((void*)state_string);
        }
    }
    
#endif
    for(stack=0;stack<8;stack++)
    {
        if (stack_len(state,stack) > 0)
        {
            break;
        }
    }
    if (stack == 8)
    {
        for(fc=0;fc<4;fc++)
        {
            if (freecell_card_num(state,fc) > 0)
            {
                break;
            }
        }
        if (fc == 4)
        {
            free(prev_states);
            num_solution_states = depth+1;
            solution_states = malloc(sizeof(char*) * num_solution_states);

            solution_states[depth] = state_as_string(&state);
              
            return 0;
        }
    }


    for(stack=0;stack<8;stack++)
    {
        cards_num = stack_len(state, stack);
        if (cards_num)
        { 
            card = stack_card(state,stack,cards_num-1);
            if (deck_value(state, card_deck(card)) == card_card_num(card) - 1)
            {

                duplicate_state (new_state, state);

                pop_stack_card(new_state, stack, temp_card);

                increment_deck(new_state, card_deck(card));

                canonize_state(&new_state);

                check = 1;

                if (bsearch(&new_state, 
                            prev_states, 
                            unsorted_prev_states_start_at, 
                            sizeof(state_t), 
                            state_compare) == NULL)
                {
                    temp_size_t = num_prev_states-unsorted_prev_states_start_at;
                    check = (
                            lfind(&new_state,
                                prev_states+unsorted_prev_states_start_at,
                                &temp_size_t,
                                sizeof(state_t),
                                state_compare) == NULL);
                }
                else
                {
                    check = 0;
                }

                if (check)
                {
                    if (num_prev_states == max_num_prev_states)
                    {
                        max_num_prev_states += PREV_STATES_GROW_BY;

                        prev_states = (state_t *)realloc(prev_states, sizeof(state_t)*max_num_prev_states);
                    }
                    
                    prev_states[num_prev_states] = new_state;
                    num_prev_states++;


                    if (num_prev_states - unsorted_prev_states_start_at >= PREV_STATES_SORT_MARGIN)
                    {
                        qsort(prev_states, num_prev_states, sizeof(state_t), state_compare);
                        unsorted_prev_states_start_at = num_prev_states;
                    }
                }                 
        
                if (check)
                {
                    ret = solve_for_state(new_state, depth+1);
                    if (!ret)
                    {
                        solution_states[depth] = state_as_string(&state);
                        return 0;
                    }
                    else
                    {
                        cards_num = stack_len(state, stack);
                        card = stack_card(state,stack,cards_num-1);


                        if ((card_deck(card) - 2 <= deck_value(state, card_deck(card)|0x1)) &&
                            (card_deck(card) - 2 <= deck_value(state, card_deck(card)|0x3)))
                        {
                            return 1;
                        }                            
                    }
                }
                else
                {
                    cards_num = stack_len(state, stack);
                    card = stack_card(state,stack,cards_num-1);


                    if ((card_deck(card) - 2 <= deck_value(state, card_deck(card)|0x1)) &&
                        (card_deck(card) - 2 <= deck_value(state, card_deck(card)|0x3)))
                    {
                        return 1;
                    }                                                
                }
            }
        }
    }

    for(fc=0;fc<4;fc++)
    {
        card = freecell_card(state, fc);
        if (card_card_num(card) != 0)
        {
            if (deck_value(state, card_deck(card)) == card_card_num(card) - 1)
            {
                duplicate_state(new_state, state);

                empty_freecell(new_state, fc);

                increment_deck(new_state, card_deck(card));

                canonize_state(&new_state);

                check = 1;
                
                if (bsearch(&new_state, 
                            prev_states, 
                            unsorted_prev_states_start_at, 
                            sizeof(state_t), 
                            state_compare) == NULL)
                {
                    temp_size_t = num_prev_states-unsorted_prev_states_start_at;
                    check = (
                            lfind(&new_state,
                                prev_states+unsorted_prev_states_start_at,
                                &temp_size_t,
                                sizeof(state_t),
                                state_compare) == NULL);
                }
                else
                {
                    check = 0;
                }

                if (check)
                {
                    if (num_prev_states == max_num_prev_states)
                    {
                        max_num_prev_states += PREV_STATES_GROW_BY;

                        prev_states = (state_t *)realloc(prev_states, sizeof(state_t)*max_num_prev_states);
                    }
                    
                    prev_states[num_prev_states] = new_state;
                    num_prev_states++;


                    if (num_prev_states - unsorted_prev_states_start_at >= PREV_STATES_SORT_MARGIN)
                    {
                        qsort(prev_states, num_prev_states, sizeof(state_t), state_compare);
                        unsorted_prev_states_start_at = num_prev_states;
                    }
                }                 
                
                if (check)
                {
                    ret = solve_for_state(new_state, depth+1);
                    if (!ret)
                    {
                        solution_states[depth] = state_as_string(&state);
                        return 0;
                    }
                    else
                    {
                        card = freecell_card(state, fc);

                        if ((card_deck(card) - 2 <= deck_value(state, card_deck(card)|0x1)) &&
                            (card_deck(card) - 2 <= deck_value(state, card_deck(card)|0x3)))
                        {
                            return 1;
                        }                            
                    }                    
                }
                else
                {
                    card = freecell_card(state, fc);
                    if ((card_deck(card) - 2 <= deck_value(state, card_deck(card)|0x1)) &&
                        (card_deck(card) - 2 <= deck_value(state, card_deck(card)|0x3)))
                    {
                        return 1;
                    }                            
                }
            }
        }
    }
       

    for(stack=0;stack<8;stack++)
    {
        cards_num = stack_len(state, stack);

        if (cards_num > 0)
        {
            card = stack_card(state, stack, cards_num-1);

            for(fc=0;fc<4;fc++)
            {
                temp_card = freecell_card(state, fc);

                if (card_card_num(temp_card) != 0)
                {

                    if ((card_card_num(card) == card_card_num(temp_card)+1) &&
                        ((card_deck(card) & 0x1) != (card_deck(temp_card) & 0x1)))
                    {
                        duplicate_state(new_state, state);

                        push_card_into_stack(new_state, stack, temp_card);

                        empty_freecell(new_state, fc);
                        
                        canonize_state(&new_state);

                        if (bsearch(&new_state, 
                                    prev_states, 
                                    unsorted_prev_states_start_at, 
                                    sizeof(state_t), 
                                    state_compare) == NULL)
                        {
                            temp_size_t = num_prev_states-unsorted_prev_states_start_at;
                            check = (
                                    lfind(&new_state,
                                        prev_states+unsorted_prev_states_start_at,
                                        &temp_size_t,
                                        sizeof(state_t),
                                        state_compare) == NULL);
                        }
                        else
                        {
                            check = 0;
                        }

                        if (check)
                        {
                            if (num_prev_states == max_num_prev_states)
                            {
                                max_num_prev_states += PREV_STATES_GROW_BY;

                                prev_states = (state_t *)realloc(prev_states, sizeof(state_t)*max_num_prev_states);
                            }
                            
                            prev_states[num_prev_states] = new_state;
                            num_prev_states++;


                            if (num_prev_states - unsorted_prev_states_start_at >= PREV_STATES_SORT_MARGIN)
                            {
                                qsort(prev_states, num_prev_states, sizeof(state_t), state_compare);
                                unsorted_prev_states_start_at = num_prev_states;
                            }
                        }                                                         

                        if (check)
                        {
                            ret = solve_for_state(new_state, depth+1);
                            if (!ret)
                            {
                                solution_states[depth] = state_as_string(&state);

                                return 0;
                            }
                        }
                    }
                }
            }
        }
    }


    {
        int num_freecells;
        int num_freestacks;

        int c, is_seq_in_src, ds, dc, is_seq_in_dest;
        card_t this_card, prev_card, dest_below_card;
        int num_cards_to_relocate, freecells_to_fill, freestacks_to_fill;

        num_freecells = 0;
        for(a=0;a<4;a++)
        {
            if (freecell_card_num(state, a) == 0)
            {
                num_freecells++;
            }
        }
        num_freestacks = 0;    
        for(a=0;a<8;a++)
        {
            if (stack_len(state, a) == 0)
            {
                num_freestacks++;
            }
        }


        
        for (stack=0;stack<8;stack++)
        {
            cards_num = stack_len(state, stack);

            for (c=0 ; c<cards_num ; c++)
            {   

                is_seq_in_src = 1;
                for(a=c+1 ; a<cards_num ; a++)
                {
                    this_card = stack_card(state, stack, a);
                    prev_card = stack_card(state, stack, a-1);

                    if ((card_card_num(prev_card) == card_card_num(this_card)+1) &&
                        ((card_deck(prev_card) & 0x1) != (card_deck(this_card) & 0x1)))
                    {
                    }
                    else
                    {
                        is_seq_in_src = 0;
                        break;
                    }
                }

                card = stack_card(state, stack, c);


                a = 1;
                if (c != 0)
                {
                    prev_card = stack_card(state, stack, c-1);
                    if ((card_card_num(prev_card) == card_card_num(card)+1) &&
                        ((card_deck(prev_card) & 0x1) != (card_deck(card) & 0x1)))
                    {
                       a = 0;  
                    }
                }
                if (a)
                {
                    for(ds=0 ; ds<8; ds++)
                    {
                        if (ds != stack)
                        {
                            dest_cards_num = stack_len(state, ds);
                            for(dc=0;dc<dest_cards_num;dc++)
                            {
                                dest_card = stack_card(state, ds, dc);

                                if ((card_card_num(card) == card_card_num(dest_card)-1) &&
                                    ((card_deck(card) & 0x1) != (card_deck(dest_card) & 0x1)))
                                {

                                    is_seq_in_dest = 0;
                                    if (dest_cards_num - 1 > dc)
                                    {
                                        dest_below_card = stack_card(state, ds, dc+1);
                                        if ((card_card_num(dest_below_card) == card_card_num(dest_card)-1) &&
                                            ((card_deck(dest_below_card) & 0x1) != (card_deck(dest_card) & 0x1)))
                                        {
                                            is_seq_in_dest = 1;
                                        }
                                    }

                                    if (! is_seq_in_dest)
                                    {
                                        if (is_seq_in_src)
                                        {
                                            num_cards_to_relocate = dest_cards_num - dc - 1;

                                            freecells_to_fill = min(num_cards_to_relocate, num_freecells);

                                            num_cards_to_relocate -= freecells_to_fill;

                                            freestacks_to_fill = min(num_cards_to_relocate, num_freestacks);

                                            num_cards_to_relocate -= freestacks_to_fill;

                                            if ((num_cards_to_relocate == 0) &&
                                               (calc_max_sequence_move(num_freecells-freecells_to_fill, num_freestacks-freestacks_to_fill) >=
                                                cards_num - c))
                                            {
                                                duplicate_state(new_state, state);

                                                for(a=0 ; a<freecells_to_fill ; a++)
                                                {
                                                    for(b=0;b<4;b++)
                                                    {
                                                        if (freecell_card_num(new_state, b) == 0)
                                                        {
                                                            break;
                                                        }
                                                    }

                                                    pop_stack_card(new_state, ds, temp_card);

                                                    put_card_in_freecell(new_state, b, temp_card);
                                                }

                                                for(a=0; a < freestacks_to_fill ; a++)
                                                {
                                                    for(b=0;b<8;b++)
                                                    {
                                                        if (stack_len(new_state, b) == 0)
                                                        {
                                                            break;
                                                        }
                                                    }

                                                    pop_stack_card(new_state, ds, temp_card);
                                                    push_card_into_stack(new_state, b, temp_card);
                                                }

                                                for(a=c ; a <= cards_num-1 ; a++)
                                                {
                                                    push_stack_card_into_stack(new_state, ds, stack, a);
                                                }

                                                for(a=0;a<cards_num-c;a++)
                                                {
                                                    pop_stack_card(new_state, stack, temp_card);
                                                }

                                                canonize_state(&new_state);

                                                if (bsearch(&new_state, 
                                                            prev_states, 
                                                            unsorted_prev_states_start_at, 
                                                            sizeof(state_t), 
                                                            state_compare) == NULL)
                                                {
                                                    temp_size_t = num_prev_states-unsorted_prev_states_start_at;
                                                    check = (
                                                            lfind(&new_state,
                                                                prev_states+unsorted_prev_states_start_at,
                                                                &temp_size_t,
                                                                sizeof(state_t),
                                                                state_compare) == NULL);
                                                }
                                                else
                                                {
                                                    check = 0;
                                                }

                                                if (check)
                                                {
                                                    if (num_prev_states == max_num_prev_states)
                                                    {
                                                        max_num_prev_states += PREV_STATES_GROW_BY;

                                                        prev_states = (state_t *)realloc(prev_states, sizeof(state_t)*max_num_prev_states);
                                                    }
                                                    
                                                    prev_states[num_prev_states] = new_state;
                                                    num_prev_states++;


                                                    if (num_prev_states - unsorted_prev_states_start_at >= PREV_STATES_SORT_MARGIN)
                                                    {
                                                        qsort(prev_states, num_prev_states, sizeof(state_t), state_compare);
                                                        unsorted_prev_states_start_at = num_prev_states;
                                                    }
                                                }                                                         

                                                if (check)
                                                {
                                                    ret = solve_for_state(new_state, depth+1);
                                                    if (!ret)
                                                    {
                                                        solution_states[depth] = state_as_string(&state); 
                                                        return 0;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (num_freestacks > 0)
        {
            for(stack=0;stack<8;stack++)
            {
                cards_num = stack_len(state, stack);

                if (cards_num)
                {
                    for(c=cards_num-2; c>=0;c--)
                    {
                        this_card = stack_card(state, stack, c+1);
                        prev_card = stack_card(state, stack, c);

                        if ((card_card_num(prev_card) == card_card_num(this_card)+1) &&
                            ((card_deck(prev_card) & 0x1) != (card_deck(this_card) & 0x1)))
                        {
                        }
                        else
                        {
                            break;
                        }
                    }
                    c = c+1;

                    if (c == 0)
                    {
                        continue;
                    }
                    while ((calc_max_sequence_move(num_freecells, num_freestacks-1) < cards_num -c) && (c > 0))
                    {                    
                        c--;
                    }                

                    
                    if (c > 0)
                    {
                        duplicate_state(new_state, state);
                        
                        for(ds=0;ds<8;ds++)
                        {
                            if (stack_len(state, ds) == 0)
                                break;
                        }

                        for(a=c ; a <= cards_num-1 ; a++)
                        {
                            push_stack_card_into_stack(new_state, ds, stack, a);
                        }

                        for(a=0;a<cards_num-c;a++)
                        {
                            pop_stack_card(new_state, stack, temp_card);
                        }

                        canonize_state(&new_state);

                        if (bsearch(&new_state, 
                                    prev_states, 
                                    unsorted_prev_states_start_at, 
                                    sizeof(state_t), 
                                    state_compare) == NULL)
                        {
                            temp_size_t = num_prev_states-unsorted_prev_states_start_at;
                            check = (
                                    lfind(&new_state,
                                        prev_states+unsorted_prev_states_start_at,
                                        &temp_size_t,
                                        sizeof(state_t),
                                        state_compare) == NULL);
                        }
                        else
                        {
                            check = 0;
                        }

                        if (check)
                        {
                            if (num_prev_states == max_num_prev_states)
                            {
                                max_num_prev_states += PREV_STATES_GROW_BY;

                                prev_states = (state_t *)realloc(prev_states, sizeof(state_t)*max_num_prev_states);
                            }
                            
                            prev_states[num_prev_states] = new_state;
                            num_prev_states++;

                            if (num_prev_states - unsorted_prev_states_start_at >= PREV_STATES_SORT_MARGIN)
                            {
                                qsort(prev_states, num_prev_states, sizeof(state_t), state_compare);
                                unsorted_prev_states_start_at = num_prev_states;
                            }
                        }                                                         

                        if (check)
                        {
                            ret = solve_for_state(new_state, depth+1);
                            if (!ret)
                            {
                                solution_states[depth] = state_as_string(&state);
                                return 0;
                            }
                        }
                    }
                }
            }
        }
        for(fc=0;fc<4;fc++)
        {
            card = freecell_card(state, fc);
            if (card_card_num(card) != 0)
            {
                for(stack=0;stack<8;stack++)
                {
                    if (stack_len(state, stack) == 0)
                    {
                        break;
                    }
                }
                if (stack != 8)
                {

                    duplicate_state(new_state, state);
                    push_card_into_stack(new_state, stack, card);
                    empty_freecell(new_state, fc);

                    canonize_state(&new_state);

                    if (bsearch(&new_state, 
                                prev_states, 
                                unsorted_prev_states_start_at, 
                                sizeof(state_t), 
                                state_compare) == NULL)
                    {
                        temp_size_t = num_prev_states-unsorted_prev_states_start_at;
                        check = (
                                lfind(&new_state,
                                    prev_states+unsorted_prev_states_start_at,
                                    &temp_size_t,
                                    sizeof(state_t),
                                    state_compare) == NULL);
                    }
                    else
                    {
                        check = 0;
                    }

                    if (check)
                    {
                        if (num_prev_states == max_num_prev_states)
                        {
                            max_num_prev_states += PREV_STATES_GROW_BY;

                            prev_states = (state_t *)realloc(prev_states, sizeof(state_t)*max_num_prev_states);
                        }
                        
                        prev_states[num_prev_states] = new_state;
                        num_prev_states++;

                        if (num_prev_states - unsorted_prev_states_start_at >= PREV_STATES_SORT_MARGIN)
                        {
                            qsort(prev_states, num_prev_states, sizeof(state_t), state_compare);
                            unsorted_prev_states_start_at = num_prev_states;
                        }
                    }                                                         

                    if (check)
                    {
                        ret = solve_for_state(new_state, depth+1);
                        if (!ret)
                        {
                            solution_states[depth] = state_as_string(&state);
                            return 0;
                        }
                    }
                }
            }
        }

        for (stack=0;stack<8;stack++)
        {
            cards_num = stack_len(state, stack);

            for (c=0 ; c<cards_num ; c++)
            {   
                is_seq_in_src = 1;
                for(a=c+1 ; a<cards_num ; a++)
                {
                    this_card = stack_card(state, stack, a);
                    prev_card = stack_card(state, stack, a-1);

                    if ((card_card_num(prev_card) == card_card_num(this_card)+1) &&
                        ((card_deck(prev_card) & 0x1) != (card_deck(this_card) & 0x1)))
                    {
                    }
                    else
                    {
                        is_seq_in_src = 0;
                        break;
                    }
                }


                card = stack_card(state, stack, c);
                a = 1;
                if (c != 0)
                {
                    prev_card = stack_card(state, stack, c-1);
                    if ((card_card_num(prev_card) == card_card_num(card)+1) &&
                        ((card_deck(prev_card) & 0x1) != (card_deck(card) & 0x1)))
                    {
                       a = 0;  
                    }
                }
                if (!a)
                {
                    for(ds=0 ; ds<8; ds++)
                    {
                        if (ds != stack)
                        {
                            dest_cards_num = stack_len(state, ds);
                            for(dc=0;dc<dest_cards_num;dc++)
                            {
                                dest_card = stack_card(state, ds, dc);

                                if ((card_card_num(card) == card_card_num(dest_card)-1) &&
                                    ((card_deck(card) & 0x1) != (card_deck(dest_card) & 0x1)))
                                {
                                    is_seq_in_dest = 0;
                                    if (dest_cards_num - 1 > dc)
                                    {
                                        dest_below_card = stack_card(state, ds, dc+1);
                                        if ((card_card_num(dest_below_card) == card_card_num(dest_card)-1) &&
                                            ((card_deck(dest_below_card) & 0x1) != (card_deck(dest_card) & 0x1)))
                                        {
                                            is_seq_in_dest = 1;
                                        }
                                    }

                                    if (! is_seq_in_dest)
                                    {
                                        if (is_seq_in_src)
                                        {
                                            num_cards_to_relocate = dest_cards_num - dc - 1;

                                            freecells_to_fill = min(num_cards_to_relocate, num_freecells);

                                            num_cards_to_relocate -= freecells_to_fill;

                                            freestacks_to_fill = min(num_cards_to_relocate, num_freestacks);

                                            num_cards_to_relocate -= freestacks_to_fill;

                                            if ((num_cards_to_relocate == 0) &&
                                               (calc_max_sequence_move(num_freecells-freecells_to_fill, num_freestacks-freestacks_to_fill) >=
                                                cards_num - c))
                                            {
                                                duplicate_state(new_state, state);
                                                for(a=0 ; a<freecells_to_fill ; a++)
                                                {
                                                    for(b=0;b<4;b++)
                                                    {
                                                        if (freecell_card_num(new_state, b) == 0)
                                                        {
                                                            break;
                                                        }
                                                    }

                                                    pop_stack_card(new_state, ds, temp_card);

                                                    put_card_in_freecell(new_state, b, temp_card);
                                                }

                                                for(a=0; a < freestacks_to_fill ; a++)
                                                {
                                                    for(b=0;b<8;b++)
                                                    {
                                                        if (stack_len(new_state, b) == 0)
                                                        {
                                                            break;
                                                        }
                                                    }

                                                    pop_stack_card(new_state, ds, temp_card);
                                                    push_card_into_stack(new_state, b, temp_card);
                                                }

                                                for(a=c ; a <= cards_num-1 ; a++)
                                                {
                                                    push_stack_card_into_stack(new_state, ds, stack, a);
                                                }

                                                for(a=0;a<cards_num-c;a++)
                                                {
                                                    pop_stack_card(new_state, stack, temp_card);
                                                }

                                                canonize_state(&new_state);

                                                if (bsearch(&new_state, 
                                                            prev_states, 
                                                            unsorted_prev_states_start_at, 
                                                            sizeof(state_t), 
                                                            state_compare) == NULL)
                                                {
                                                    temp_size_t = num_prev_states-unsorted_prev_states_start_at;
                                                    check = (
                                                            lfind(&new_state,
                                                                prev_states+unsorted_prev_states_start_at,
                                                                &temp_size_t,
                                                                sizeof(state_t),
                                                                state_compare) == NULL);
                                                }
                                                else
                                                {
                                                    check = 0;
                                                }

                                                if (check)
                                                {
                                                    if (num_prev_states == max_num_prev_states)
                                                    {
                                                        max_num_prev_states += PREV_STATES_GROW_BY;

                                                        prev_states = (state_t *)realloc(prev_states, sizeof(state_t)*max_num_prev_states);
                                                    }
                                                    
                                                    prev_states[num_prev_states] = new_state;
                                                    num_prev_states++;

                                                    if (num_prev_states - unsorted_prev_states_start_at >= PREV_STATES_SORT_MARGIN)
                                                    {
                                                        qsort(prev_states, num_prev_states, sizeof(state_t), state_compare);
                                                        unsorted_prev_states_start_at = num_prev_states;
                                                    }
                                                }                                                         

                                                if (check)
                                                {
                                                    ret = solve_for_state(new_state, depth+1);
                                                    if (!ret)
                                                    {
                                                        solution_states[depth] = state_as_string(&state);
                                                        return 0;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        for(stack=0;stack<8;stack++)
        {
            cards_num = stack_len(state, stack);
            for(c=cards_num-2 ; c >= 0 ; c--)
            {
                card = stack_card(state, stack, c);
                if (deck_value(state, card_deck(card)) == card_card_num(card)-1)
                {

                    if (num_freecells + num_freestacks >= cards_num-(c+1))
                    {

                        duplicate_state(new_state, state);
                        for(a=0 ; a<min(num_freecells, cards_num-(c+1)) ; a++)
                        {
                            for(b=0; b<4; b++)
                            {
                                if (freecell_card_num(new_state, b) == 0)
                                {
                                    break;
                                }
                            }
                            pop_stack_card(new_state, stack, temp_card);

                            put_card_in_freecell(new_state, b, temp_card);
                        }

                        for(a=0; a < cards_num-(c+1) - min(num_freecells, cards_num-(c+1)) ; a++)
                        {

                            for(b=0;b<8;b++)
                            {
                                if (stack_len(new_state, b) == 0)
                                {
                                    break;
                                }
                            }

                            pop_stack_card(new_state, stack, temp_card);
                            push_card_into_stack(new_state, b, temp_card);
                        }

                        pop_stack_card(new_state, stack, temp_card);
                        increment_deck(new_state, card_deck(temp_card));

                        canonize_state(&new_state);

                        if (bsearch(&new_state, 
                                    prev_states, 
                                    unsorted_prev_states_start_at, 
                                    sizeof(state_t), 
                                    state_compare) == NULL)
                        {
                            temp_size_t = num_prev_states-unsorted_prev_states_start_at;
                            check = (
                                    lfind(&new_state,
                                        prev_states+unsorted_prev_states_start_at,
                                        &temp_size_t,
                                        sizeof(state_t),
                                        state_compare) == NULL);
                        }
                        else
                        {
                            check = 0;
                        }

                        if (check)
                        {
                            if (num_prev_states == max_num_prev_states)
                            {
                                max_num_prev_states += PREV_STATES_GROW_BY;

                                prev_states = (state_t *)realloc(prev_states, sizeof(state_t)*max_num_prev_states);
                            }
                            
                            prev_states[num_prev_states] = new_state;
                            num_prev_states++;



                            if (num_prev_states - unsorted_prev_states_start_at >= PREV_STATES_SORT_MARGIN)
                            {
                                qsort(prev_states, num_prev_states, sizeof(state_t), state_compare);
                                unsorted_prev_states_start_at = num_prev_states;
                            }
                        }                                                         

                        if (check)
                        {
                            ret = solve_for_state(new_state, depth+1);
                            if (!ret)
                            {
                                solution_states[depth] = state_as_string(&state);
                                return 0;
                            }
                        }
                    }
                }
            }
        }


        if (num_freestacks == 0)
        {
            for(stack=0;stack<8;stack++)
            {
                cards_num = stack_len(state, stack);
                if (cards_num <= num_freecells)
                {

                    duplicate_state(new_state, state);
                    for(c=0;c<cards_num;c++)
                    {

                        for(b=0; b<4; b++)
                        {
                            if (freecell_card_num(new_state, b) == 0)
                            {
                                break;
                            }
                        }
                        pop_stack_card(new_state, stack, temp_card);

                        put_card_in_freecell(new_state, b, temp_card);
                    }

                    canonize_state(&new_state);

                    if (bsearch(&new_state, 
                                prev_states, 
                                unsorted_prev_states_start_at, 
                                sizeof(state_t), 
                                state_compare) == NULL)
                    {
                        temp_size_t = num_prev_states-unsorted_prev_states_start_at;
                        check = (
                                lfind(&new_state,
                                    prev_states+unsorted_prev_states_start_at,
                                    &temp_size_t,
                                    sizeof(state_t),
                                    state_compare) == NULL);
                    }
                    else
                    {
                        check = 0;
                    }

                    if (check)
                    {
                        if (num_prev_states == max_num_prev_states)
                        {
                            max_num_prev_states += PREV_STATES_GROW_BY;

                            prev_states = (state_t *)realloc(prev_states, sizeof(state_t)*max_num_prev_states);
                        }
                        
                        prev_states[num_prev_states] = new_state;
                        num_prev_states++;

                        if (num_prev_states - unsorted_prev_states_start_at >= PREV_STATES_SORT_MARGIN)
                        {
                            qsort(prev_states, num_prev_states, sizeof(state_t), state_compare);
                            unsorted_prev_states_start_at = num_prev_states;
                        }
                    }                                                         

                    if (check)
                    {
                        ret = solve_for_state(new_state, depth+1);
                        if (!ret)
                        {
                            solution_states[depth] = state_as_string(&state);
                            return 0;
                        }
                    }
                }
            }
        }
    }
    return 1;
}

#ifdef DEBUG

int command_num = 0;

void select_signal_handler(int signal_num)
{
    command_num = (command_num+1)%3;
}


void command_signal_handler(int signal_num)
{
    if (command_num == 0)
    {
        fprintf(stderr, "The number of iterations is %i\n", num_times);
    }
    else if (command_num == 1)
    {
        debug_iter_output = ! debug_iter_output;
    }
    else if (command_num == 2)
    {
        debug_iter_state_output = ! debug_iter_state_output;
    }

    command_num = 0;
}

#endif

char * help_string = 
"fc-solve [options] board_file\n"
"\n"
"If board_file is - or unspecified reads standard input\n"
"\n"
"Availalble Options:\n"
"-h   --help           - display this help screen\n"
"-i   --iter-output    - display the iteration number and depth in every state that is checked\n"
"                              ( applicable only for fc-solve-debug )\n"
"-s   --state-output   - also output the state in every state that is checked\n"
"                              ( applicable only for fc-solve-debug )\n"
"\n"
"Signals: (applicable only for fc-solve-debug)\n"
"SIGUSR1 - Prints the number of states that were checked so far to stderr.\n"
"SIGUSR2 SIGUSR1 - Turns iteration output on/off.\n"
"SIGUSR2 SIGUSR2 SIGUSR1 - Turns iteration's state output on/off.\n"
"\n"
;


int main(int argc, char * argv[])
{
    char user_state[1024];

    FILE * file;

    state_t state;
    int a;
    int ret;

    int arg;

    for(arg=1;arg<argc;arg++)
    {
        if ((!strcmp(argv[arg], "-h")) || (!strcmp(argv[arg], "--help")))
        {
            printf("%s", help_string);
            return 0;
        }
        else if ((!strcmp(argv[arg], "-i")) || (!strcmp(argv[arg], "--iter-output")))
        {
            debug_iter_output = 1;
        }
        else if ((!strcmp(argv[arg], "-s")) || (!strcmp(argv[arg], "--state-output")))
        {
            debug_iter_state_output = 1;
        }
        else
        {
            break;
        }        
    }

    
    if ((arg == argc) || (!strcmp(argv[arg], "-")))
    {
        file = stdin;
    }
    else
    {
        file = fopen(argv[arg], "r");
    }
    fread(user_state, sizeof(user_state[0]), sizeof(user_state)/sizeof(user_state[0]), file);
    fclose(file);
        
   



    state = initial_user_state_to_c(user_state);

    canonize_state(&state);

    max_num_prev_states = PREV_STATES_GROW_BY;

    prev_states = (state_t *)malloc(max_num_prev_states*sizeof(state_t));

    prev_states[0] = state;

    num_prev_states = 1;



#ifdef DEBUG
    signal(SIGUSR1, command_signal_handler);
    signal(SIGUSR2, select_signal_handler);

#endif
    
    ret = solve_for_state(state, 0);

    if (!ret)
    {
        int a;

        printf("-=-=-=-=-=-=-=-=-=-=-=-\n\n");
        for(a=0;a<num_solution_states;a++)
        {
            printf("%s\n\n====================\n\n", solution_states[a]);
            free((void*)solution_states[a]);
        }
        free((void*)solution_states);
    }
    else
    {
        free(prev_states);
        printf ("I couldn't solve this game.\n");
    }

    printf ("Total number of states checked is %i.\n", num_times);


    return 0;
}
